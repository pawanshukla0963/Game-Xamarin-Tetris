﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace AnotherTetrisCross.Views
{
    public partial class HighScoreView : StackLayout
    {
        public HighScoreView()
        {
            InitializeComponent();
        }
    }
}
