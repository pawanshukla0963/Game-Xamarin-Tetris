﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AnotherTetrisCross.ViewPages
{
    public partial class HighScoresSummaryViewPage : ContentPage
    {
        public HighScoresSummaryViewPage()
        {
            InitializeComponent();
            Debug.WriteLine("==============================> HighScoresSummaryViewPage standard c'tor");
        }
    }
}
