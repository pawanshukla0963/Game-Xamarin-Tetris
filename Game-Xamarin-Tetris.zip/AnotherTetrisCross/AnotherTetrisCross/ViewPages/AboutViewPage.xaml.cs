﻿namespace AnotherTetrisCross.ViewPages
{
    using System;
    using System.Diagnostics;
    using Xamarin.Forms;

    public partial class AboutViewPage : ContentPage
    {
        public AboutViewPage()
        {
            InitializeComponent();
            Debug.WriteLine("==============================> AboutViewPage c'tor");
        }
    }
}
