﻿namespace AnotherTetrisModel
{
    public enum GameState { GameIdle, GameRunning, GamePaused, GameOver }
}
