﻿namespace AnotherTetrisModel
{
    public enum CellState { Free, Used }
}
