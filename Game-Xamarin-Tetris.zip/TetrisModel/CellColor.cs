﻿namespace AnotherTetrisModel
{
    public enum CellColor
    {
        LightGray,
        Cyan,        // I
        Blue,        // J
        Ocker,       // L
        Yellow,      // O
        Green,       // S
        Magenta,     // T
        Red          // Z
    }
}
