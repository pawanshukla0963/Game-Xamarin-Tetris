﻿namespace AnotherTetrisModel
{
    public enum TetriminoAction { None, Left, Right, Rotate, BeginAllWayDown, EndAllWayDown }
}
