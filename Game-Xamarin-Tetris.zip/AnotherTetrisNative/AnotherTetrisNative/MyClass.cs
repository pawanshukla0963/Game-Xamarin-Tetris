﻿using System;

namespace AnotherTetrisNative
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}

